# blind-v3: blind evaluation set for the Niveshak Saathi message checker

`blind-v3.json` holds 320 short, synthetic messages of the kind Indian investors receive by SMS, WhatsApp, Telegram, social media, email and phone. Each one is labelled `fraud`, `suspicious` or `benign`. Use the set **only for the final accuracy measurement**. Do not tune rules or prompts on it, and do not train on it.

## 1. Blindness

- The set was written on 2026-10-01 by an independent Claude agent in one session.
- The author did **not** open, read or search any of these: anything under `outputs\`, any `engine.js`, `Rule-Evaluation.json`, `Evaluate-Rules.cjs`, or anything under `work\claude-tests\` other than this `corpus` folder. The `corpus` folder did not exist before; it was created new.
- The author did not look at the app and did not run the checker on any item. No item was revised in response to checker output.
- The author worked in a temporary scratch folder that is shared with other sessions. Listing it once showed the names of unrelated files, some of them evaluation scripts. None were opened.
- The set is blind to the checker's code, **not** to the domain. The author and the checker's designers probably both drew on the same public knowledge: SEBI, RBI, NSE and police advisories, plus news reports. Some shared vocabulary is expected.

## 2. File format

```
{ "version": "blind-v3", "createdAt": "2026-10-01", "author": "...", "taxonomy": {16 signal ids → definition},
  "items": [ { "id", "lang", "channel", "label", "hard", "signals", "text", "note" } ] }
```

- `id`: `b001` to `b320`. Ids were assigned after a seeded shuffle (`random.Random(20261001)`), so id order carries no information about label, language or type.
- `lang`:
  - `en`
  - `hi`: Devanagari. Like real Hindi messages, it keeps acronyms such as KYC, OTP, UPI and IPO in Latin script.
  - `hinglish`: Hindi or mixed Hindi-English in Latin script.
- `channel`:
  - `sms`, `whatsapp`, `telegram`, `email`
  - `social`: Instagram, Facebook and YouTube comments or ads, and LinkedIn-style DMs
  - `call`: a transcript of the caller's words only

  The channel is metadata. The checker should be given `text` only.
- `label`:
  - **fraud**: a clear attempt to get money, credentials or device access by deception.
  - **suspicious**: risky, but not clearly a scam on its own. Examples: a free tips channel, an unsolicited multibagger tip, a suggestion to take a loan to trade F&O, an informal scheme with high "fixed" returns.
  - **benign**: an ordinary, legitimate message.
- `hard`: the meaning depends on the label.
  - fraud: *subtle*, with only one or two weak signs.
  - suspicious: *low-cue*, meaning it looks harmless at first glance.
  - benign: a *hard negative*, meaning risky-looking vocabulary in a safe context.
- `signals`: the taxonomy ids a careful human would flag.
  - Benign items always have `[]`.
  - Every fraud and suspicious item has at least one signal.
  - For hard negatives, the risky vocabulary is named only in `note`, in the form `Hard negative [credentials, urgency]: ...`.
- `note`: a short reason for the label. Subtle fraud notes start with `Subtle`, and hard-negative notes start with `Hard negative`.

## 3. Method

1. **Plan.** The author fixed the targets first: 40% fraud, 20% suspicious, 40% benign; 35% English, 30% Hindi (Devanagari), 35% Hinglish. More targets were at least half of benign items as hard negatives, about 15% of fraud items as subtle, and coverage of every fraud and suspicious type in the brief.
2. **Write.** Every message was written by hand, one at a time, in nine blocks (label × language). Each message got its signals and a note as it was written. The same scheme types appear in all three languages, with different wording rather than translations, and are spread across channels.
3. **Vary the surface.** The set includes:
   - lengths from one line to an email-sized paragraph
   - polite and professional fraud as well as crude fraud
   - emoji, ALL-CAPS Telegram posts, letter-spaced filter evasion (`G u a r a n t e e d`, `S.E.B.I`)
   - Devanagari digits (₹६,४८,२००) and `Rs`, `₹`, `lakh`, `k`
   - Hinglish spelling variants: paisa/paise/pesa, guarantee/gaaranti/garanti, munafa/fayda/faida, roz/rozana, turant, abhi
4. **Fix shortcut artefacts.** A first statistics pass showed artefacts a checker could exploit for the wrong reasons, so the author fixed them:
   - Benign messages almost never had links or UPI IDs. Official-domain links went into 9 more benign items, and UPI IDs into 2.
   - No fraud message was short. Five fraud items were shortened, so the shortest is now 61 characters.
   - No benign message mentioned a legitimate withdrawal fee. Exit-load and FD-penalty messages were added.
5. **Validate.** A script checked:
   - the shape of every item and the allowed values
   - that every signal is in the taxonomy
   - that benign items have no signals and fraud and suspicious items have at least one
   - that `hi` items contain Devanagari and other items do not
   - that no text is repeated, even as a near-duplicate prefix
   - that the note prefixes match the `hard` flag

   The written file was parsed again with Python `json` and with PowerShell `ConvertFrom-Json`. Both found 320 items, 320 unique ids and 0 unknown signals. The build scripts were temporary and are not part of the deliverable; `blind-v3.json` is the source of truth.

**Names.** No real person, broker or company is named. Every bank, broker, fund, stock, app, club, phone number, UPI ID, account number, IFSC code and fraud domain is invented. Some invented names may match a real entity by accident; no link is intended. Do not contact any number or domain in the set.

Invented names in the set:

| Kind | Names |
|---|---|
| Bank, broker, insurer, funds | Navdhara Bank (IFSC prefix NVDB), Tarkash Securities (`console.tarkash.in`), Sumeru Life Insurance, Nivora / Ushmi / Tvisha mutual funds |
| Stocks | Velmora Agro, Kantiveer Infra, Rudhrani Textiles, Noventa Polymers |
| IPO | Avantra Organics |
| Fraud brands | ZenithBull Pro, AlotMax, BullRun Pro, KryptoKul, Meghvarn Capital Advisors, Arvaksha Research, Vittaksha Capital, Vyomika Research, and others |

Real names appear only where impersonating them is the point, or where they are public infrastructure:
- regulators and agencies: SEBI, RBI, NSE, BSE, CDSL, DICGC, CBI, ED, customs, police
- platforms and tools: WhatsApp, Telegram, Play Store / App Store, AnyDesk, TeamViewer, QuickSupport
- official sites in benign items: `www.sebi.gov.in`, `cybercrime.gov.in`, `www.nseindia.com`
- the 1930 cybercrime helpline
- one real URL shortener, `bit.ly`, in one fraud item. The other short links use invented shorteners.

Celebrity-deepfake ads describe a celebrity ("one of India's most-loved film superstars", "famous cricket captain") and never name one.

## 4. Counts

### Label × language

| label | en | hi | hinglish | total | share |
|---|---:|---:|---:|---:|---:|
| fraud | 45 | 38 | 45 | 128 | 40.0% |
| suspicious | 22 | 19 | 23 | 64 | 20.0% |
| benign | 45 | 39 | 44 | 128 | 40.0% |
| **total** | **112** | **96** | **112** | **320** | 100% |
| share | 35.0% | 30.0% | 35.0% | | |

### `hard = true` by label × language

| label (meaning of `hard`) | en | hi | hinglish | total | share of label |
|---|---:|---:|---:|---:|---:|
| fraud (subtle) | 7 | 7 | 7 | 21 | 16.4% |
| suspicious (low-cue) | 4 | 4 | 5 | 13 | 20.3% |
| benign (hard negative) | 31 | 23 | 24 | 78 | 60.9% |

The other 50 benign items are easy negatives: 14 en, 16 hi, 20 hinglish.

### Channel × label

| channel | fraud | suspicious | benign | total |
|---|---:|---:|---:|---:|
| sms | 29 | 11 | 27 | 67 |
| whatsapp | 37 | 24 | 50 | 111 |
| telegram | 16 | 9 | 4 | 29 |
| social | 10 | 11 | 23 | 44 |
| email | 12 | 4 | 15 | 31 |
| call | 24 | 5 | 9 | 38 |

### Signals

- Each cell counts the items that carry the signal.
- The "fraud (subtle)" column is a subset of the "fraud" column.
- The last column counts the hard negatives whose `note` names that vocabulary. Those are not labels.

| signal | fraud | fraud (subtle) | suspicious | fraud + suspicious | hard negatives citing it |
|---|---:|---:|---:|---:|---:|
| certainty | 38 | 0 | 6 | 44 | 15 |
| unrealistic-return | 51 | 1 | 21 | 72 | 5 |
| urgency | 58 | 0 | 1 | 59 | 9 |
| personal-payment | 38 | 2 | 0 | 38 | 9 |
| credentials | 12 | 3 | 0 | 12 | 16 |
| remote-access | 5 | 1 | 0 | 5 | 4 |
| chat-group | 13 | 0 | 15 | 28 | 9 |
| borrowing | 4 | 0 | 12 | 16 | 7 |
| withdrawal-fee | 15 | 5 | 0 | 15 | 3 |
| unverified-app | 12 | 2 | 4 | 16 | 4 |
| impersonation | 42 | 3 | 0 | 42 | 8 |
| tips | 17 | 2 | 36 | 53 | 5 |
| threat | 24 | 0 | 0 | 24 | 10 |
| suspicious-link | 28 | 3 | 4 | 32 | 0 |
| fake-ipo | 17 | 3 | 3 | 20 | 7 |
| recovery-offer | 7 | 0 | 0 | 7 | 2 |

Signals per item:

| signals per item | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---:|---:|---:|---:|---:|---:|---:|
| fraud items | 28 | 21 | 24 | 43 | 7 | 3 | 2 |
| suspicious items | 28 | 34 | 2 | 0 | 0 | 0 | 0 |

Six hard negatives name no specific signal; their risk is general investment vocabulary.

### Length and surface features

| label | min chars | median | max |
|---|---:|---:|---:|
| fraud | 61 | 194 | 430 |
| suspicious | 75 | 133 | 243 |
| benign | 24 | 144 | 423 |

| feature (items) | fraud | suspicious | benign |
|---|---:|---:|---:|
| URL or bare domain | 32 | 13 | 14 |
| emoji | 42 | 24 | 21 |
| Devanagari digits | 1 | 0 | 3 |
| run of ALL-CAPS words | 4 | 2 | 1 |
| letter-spaced words | 1 | 0 | 0 |
| UPI ID | 10 | 0 | 2 |
| multi-line (email-style) | 8 | 0 | 3 |

### Coverage by primary type

Each item has exactly one primary type, assigned by the author. Many items also show the features of other types; the signal table above captures those.

#### Fraud items (`hard` = subtle)

| code | type | n | en | hi | hinglish | hard | ids |
|---|---|---:|---:|---:|---:|---:|---|
| T1 | Fake trading app / VIP stock group / 'mentor' funnel (incl. pig-butchering, shill comments) | 8 | 2 | 2 | 4 | 3 | b058, b060, b084, b095, b138, b178, b206, b312 |
| T2 | Institutional account, QIB/anchor quota, pre-IPO, guaranteed IPO allotment | 11 | 5 | 3 | 3 | 3 | b044, b089, b116, b119, b129, b139, b237, b279, b304, b310, b320 |
| T3 | Guaranteed / assured returns | 3 | 1 | 0 | 2 | 0 | b122, b136, b223 |
| T4 | Unrealistic returns / money doubling | 4 | 1 | 1 | 2 | 0 | b031, b148, b222, b227 |
| T5 | Paid premium tips or signals ('100% accuracy') | 7 | 2 | 2 | 3 | 0 | b121, b140, b183, b186, b242, b256, b295 |
| T6 | Operator / pump-and-dump tip | 4 | 2 | 1 | 1 | 0 | b216, b232, b284, b302 |
| T7 | Fee, tax or deposit to withdraw profits or release a prize | 9 | 3 | 2 | 4 | 4 | b029, b065, b073, b099, b149, b198, b236, b267, b294 |
| T8 | Recovery-agent scam | 7 | 3 | 2 | 2 | 0 | b001, b025, b030, b143, b162, b163, b308 |
| T9 | SEBI/RBI/NSE/BSE/police/CBI/ED/customs impersonation, digital arrest, 'safe account' | 15 | 5 | 5 | 5 | 0 | b004, b055, b087, b106, b126, b132, b144, b150, b184, b218, b250, b259, b264, b297, b311 |
| T10 | Fake 'SEBI registered/approved' scheme or adviser | 4 | 1 | 2 | 1 | 0 | b081, b123, b146, b171 |
| T11 | KYC/demat block threat with link | 3 | 1 | 1 | 1 | 0 | b071, b207, b253 |
| T12 | OTP / UPI PIN / password / CVV request | 9 | 3 | 4 | 2 | 3 | b034, b045, b067, b173, b243, b247, b251, b276, b314 |
| T13 | Remote-access app or screen sharing | 5 | 2 | 2 | 1 | 1 | b017, b037, b038, b147, b268 |
| T14 | APK / unofficial app download | 6 | 2 | 1 | 3 | 1 | b028, b068, b170, b208, b224, b292 |
| T15 | Lookalike-domain phishing | 3 | 1 | 0 | 2 | 3 | b157, b185, b260 |
| T16 | Payment redirected to a personal or third-party account | 3 | 1 | 1 | 1 | 2 | b134, b158, b201 |
| T17 | Borrow to invest | 3 | 1 | 1 | 1 | 0 | b033, b062, b078 |
| T18 | Deepfake / celebrity investment ad | 5 | 2 | 1 | 2 | 0 | b046, b082, b096, b142, b165 |
| T19 | Crypto / forex bot or platform with daily returns | 4 | 2 | 1 | 1 | 0 | b014, b079, b271, b280 |
| T20 | Ponzi / referral scheme | 5 | 2 | 1 | 2 | 0 | b018, b175, b219, b261, b307 |
| T21 | Unauthorised deposit or committee scheme | 5 | 2 | 2 | 1 | 0 | b125, b200, b209, b210, b288 |
| T22 | Task scam ending in an 'investment' | 3 | 1 | 1 | 1 | 0 | b066, b092, b257 |
| T23 | Other (account renting / mule, unclaimed-shares fee) | 2 | 0 | 2 | 0 | 1 | b070, b309 |
| | **total** | **128** | | | | | |

#### Suspicious items (`hard` = low-cue)

| code | type | n | en | hi | hinglish | hard | ids |
|---|---|---:|---:|---:|---:|---:|---|
| S1 | Free tips channel / group invite, or call to add you to a group | 14 | 4 | 4 | 6 | 4 | b020, b103, b113, b127, b155, b176, b179, b180, b189, b191, b193, b197, b244, b303 |
| S2 | Unsolicited stock tip or free-tips offer (no payment ask) | 16 | 7 | 4 | 5 | 4 | b003, b006, b012, b042, b080, b083, b086, b088, b094, b145, b152, b160, b203, b272, b291, b319 |
| S3 | Loan, credit card or leverage to trade | 12 | 4 | 4 | 4 | 0 | b022, b069, b075, b112, b114, b156, b174, b194, b204, b229, b296, b299 |
| S4 | Finfluencer post or cold DM with high-return claims | 9 | 3 | 3 | 3 | 2 | b043, b090, b128, b164, b168, b187, b202, b226, b235 |
| S5 | Informal or unregulated scheme (committee, MLM, fractional land, P2P, presale, private fund) | 6 | 1 | 2 | 3 | 3 | b041, b059, b093, b100, b230, b318 |
| S6 | Pre-IPO / unlisted share pitch | 3 | 1 | 1 | 1 | 0 | b026, b051, b217 |
| S7 | App outside official stores / unknown crypto app | 4 | 2 | 1 | 1 | 0 | b057, b085, b238, b300 |
| | **total** | **64** | | | | | |

#### Benign items (`hard` = hard negative)

| code | type | n | en | hi | hinglish | hard | ids |
|---|---|---:|---:|---:|---:|---:|---|
| N1 | OTP / PIN / login alerts that say 'do not share' | 5 | 3 | 2 | 0 | 5 | b063, b111, b166, b169, b172 |
| N2 | Broker, exchange, depository and KYC notices (margin call, IPO reminder/status, F&O risk disclosure) | 15 | 7 | 5 | 3 | 15 | b039, b072, b141, b151, b181, b211, b213, b214, b239, b248, b249, b277, b285, b286, b305 |
| N3 | Mutual fund, insurance and FD transaction messages (SIP, exit load, 'guaranteed additions', FD penalty) | 6 | 4 | 2 | 0 | 6 | b023, b040, b196, b245, b275, b290 |
| N4 | Official, broker or creator awareness advisories | 11 | 5 | 3 | 3 | 11 | b011, b015, b052, b091, b097, b098, b110, b117, b137, b246, b316 |
| N5 | News headlines about markets or fraud arrests | 7 | 3 | 3 | 1 | 7 | b005, b027, b205, b228, b265, b270, b282 |
| N6 | Family/friend chats about FDs, SIPs, gold, loans, schemes | 14 | 3 | 4 | 7 | 14 | b008, b010, b032, b047, b104, b107, b120, b159, b161, b199, b241, b255, b293, b301 |
| N7 | Genuine loan / credit-card offers without pressure | 4 | 2 | 1 | 1 | 4 | b036, b074, b215, b281 |
| N8 | Friend, family or victim warnings about scams | 9 | 1 | 2 | 6 | 9 | b019, b105, b131, b167, b220, b262, b263, b278, b315 |
| N9 | Everyday personal payment requests (friend, family, housing society) | 4 | 2 | 0 | 2 | 4 | b056, b077, b102, b154 |
| N10 | Genuine bank/branch calls that ask for nothing sensitive | 3 | 1 | 1 | 1 | 3 | b013, b190, b233 |
| E | Ordinary messages (easy negatives) | 50 | 14 | 16 | 20 | 0 | b002, b007, b009, b016, b021, b024, b035, b048, b049, b050, b053, b054, b061, b064, b076, b101, b108, b109, b115, b118, b124, b130, b133, b135, b153, b177, b182, b188, b192, b195, b212, b221, b225, b231, b234, b240, b252, b254, b258, b266, b269, b273, b274, b283, b287, b289, b298, b306, b313, b317 |
| | **total** | **128** | | | | | |

## 5. Suggested scoring

1. **Headline metric: binary warn vs. no-warn.** Treat fraud and suspicious as positives (192 items) and benign as negatives (128 items). This metric is robust to the fraud/suspicious boundary, which is a judgement call (see section 6). Report:
   - recall on **fraud** and on **suspicious** separately
   - false-positive rate on benign overall, and separately on the **78 hard negatives** and the **50 easy negatives**
2. **Three-way view.** If the checker outputs severity levels, report the 3 × k confusion matrix. The costliest error is fraud rated as safe; the next is a warning on an ordinary benign message.
3. **Slices.** Also report results:
   - per language (en / hi / hinglish)
   - per channel
   - for the 21 subtle fraud items
   - per primary type, using the ids in the tables above
4. **Reasons.** If the checker reports reasons, compare them with `signals` as an indicative per-signal recall. The signals come from one annotator, so do not treat them as ground truth for precision.
5. **Uncertainty.** Expect sampling error:
   - With 128 fraud items, a measured recall of about 90% has a 95% interval of roughly ±5 points.
   - A 5% false-positive rate on 128 benign items has an interval of roughly 2% to 10%.
   - Cells of 3 to 5 items (many types and signals) say almost nothing on their own.

## 6. Known weaknesses and limitations

**Source and annotation**
- **Synthetic, one author, one sitting.** Nothing comes from real victims, real SMS or WhatsApp logs, or complaint data. The style is probably cleaner, more grammatical and more uniform than real traffic. Real traffic has typos, broken Unicode, forwarded headers, script switching inside one sentence, images, QR codes and voice notes.
- **Single annotator.** One model chose every label and signal, and no inter-annotator agreement was measured. These items are the most contestable:
  - benign items a strict reviewer might call suspicious, because sender authenticity cannot be verified from text: **b077, b154, b190, b239, b249, b286**
  - suspicious items that are often the first step of a scam and that others might label fraud: **b020, b043, b059, b100, b176, b197, b235**
  - fraud items with weak or indirect asks that others might label suspicious: **b058, b060, b070, b084, b206, b210, b312**

**Distribution**
- **Balance set by design.** The 40/20/40 split and the 61% share of hard negatives among benign items do not reflect real-world prevalence. Precision and false-positive rates measured here will not carry over to field traffic. The benign false-positive rate here is deliberately pessimistic.
- **Low entity diversity in benign items.** Benign messages reuse a few invented senders (Navdhara Bank, Tarkash Securities). Fraud items use many invented brands. A model trained on this set could learn the names, which is another reason not to train on it.
- **Fictional domains and senders.** A checker that relies on allowlists of real bank or broker domains and sender IDs gets no help here. Benign items with invented official-looking domains (`console.tarkash.in`, `nivoramf.com`, `navdharabank.in`) may be flagged by such a checker even though a human would accept them. Only six fraud domains imitate real regulators or market bodies:
  - `sebi-gov.in-notice.com`
  - `nse-india-verify.com`
  - `nseindia.kyc-update.in`
  - `rbi-gov-verify.in`
  - `bse-compliance-pay.com`
  - `cdsl-bonus-claim.in`

**Format and coverage**
- **Text only.** There are no sender IDs, headers, timestamps, attachments or screenshots, and no multi-turn conversations: each item is a single message. Call items are tidy transcripts of the caller's side only.
- **Language coverage.** Devanagari items lean toward standard Hindi. There is no Marathi, Bengali, Tamil or other Indian language, and no dialectal Hindi. Hinglish spelling variation is present but narrower than in real life.
- **Thin cells.** Several fraud types and some signals (for example remote-access 5 and recovery-offer 7) have only 3 to 7 items.
- **Types not covered.** SIM-swap, loan-app harassment, insurance-policy revival, fake customer-care numbers found through search, and long romance-scam threads are absent. The two pig-butchering items are single messages, not threads.
- **Time-bound details.** Interest rates, the SEBI F&O risk-disclosure wording and holiday dates are approximations as of October 2026. Scam scripts change quickly, so this set will age.
