# blind-v4: blind evaluation set for the Niveshak Saathi message checker

`blind-v4.json` holds 320 short, synthetic messages, each labelled `fraud`, `suspicious` or `benign`. They imitate what Indian users receive by SMS, WhatsApp, Telegram, social media comments and ads, email, and phone calls (written as the caller's words). The set is only for the **final accuracy measurement** of the checker. Do not use it to tune rules or thresholds.

- File: `blind-v4.json` (UTF-8 without BOM, 150,652 bytes)
- SHA-256: `FD57396D38668C2D8448C8A773047A75556487C55669ED7111D01405B89BBA47`
- Created: 2026-10-01, by one independent Claude agent

## Blindness

The author worked blind to the checker and to earlier test sets. It did not open, read, list or search anything under `outputs/`, any other folder under `work/claude-tests/`, any file named `engine.js`, `Rule-Evaluation.json`, `evaluation-cases.json`, `blind-v3.json` or `README-blind-v3.md`, or any scratchpad folder. It did not run the app or the checker. Every message was written from scratch for this set. The only things checked by machine were the JSON format and the counts. Earlier sets draw on the same public scam typology, so some overlap in themes is possible, but none of the wording was copied.

## Schema

```
{ "version": "blind-v4", "createdAt": "2026-10-01", "author": "...",
  "taxonomy": { <signal id>: <one-line definition> },
  "items": [ { "id": "c001", "lang": "en|hi|hinglish",
               "channel": "sms|whatsapp|telegram|social|email|call",
               "label": "fraud|suspicious|benign", "hard": true|false,
               "signals": [<signal ids>], "text": "...", "note": "..." } ] }
```

- **fraud**: a clear attempt to get money, credentials or device access by deception.
- **suspicious**: risky, but not clearly a scam on its own. Examples: an unsolicited tip with no payment ask, a free tips channel or group invite, advice to borrow in order to trade, a "mentor" opener, an unknown app or algo pitch.
- **benign**: an ordinary, legitimate message.
- **hard** means something different for each label:
  - benign: a *hard negative*, where risky-looking words (OTP, do not share, blocked, penalty, guaranteed, IPO, loan, KYC, freeze, digital arrest…) appear in a safe context.
  - fraud: a *subtle* fraud with only one or two weak or polite signs.
  - suspicious: *borderline*, close to benign (for example a broker's leverage upsell or an influencer pick that carries a disclaimer).
- **signals** lists what a careful human would flag. All 128 benign items have `[]`. Every fraud and suspicious item has at least one signal. The 16 ids are exactly the requested ones, and each is defined in `taxonomy`.
- **channel** is metadata. The text alone does not always reveal the channel.

## How the set was built

- Written in 10 batches of 32. Each batch had a fixed quota of label × language cells, and items were interleaved inside each batch so the ids carry no information about the label.
- All entities are made up. Banks: Sitara, Aravali, Shikhar. Brokers: Kalpvriksh Broking, Arthsetu Capital, Navdhan Securities, Trivani Securities. Fund houses: Kalash MF, Udaya MF. Also made up: the apps and platforms (ZenvestPro, TradeNest, BlockStreet Pro, Vexora…), the domains (`sebi-gov.in-kyc.help`, `nseindia-dues.co`, `bse-ipf-claims.org`, `*.apk.link`…), the UPI IDs, and the 10-digit phone numbers. One foreign number comes from the UK range reserved for fiction (+44 7700 900xxx).
- Regulators, exchanges and agencies are named where realistic: SEBI, RBI, NSE, BSE, TRAI, CBI, ED, NCB, customs, police, 1930. Celebrities are described only ("the cricket legend everyone loves", "a senior RBI official"), never named.
- Tone was varied on purpose. Many frauds are polite and professional (assistant to a "professor", a "client onboarding" email, a "relationship manager", an "AML clearance" request). Others are cartoonish (ALL CAPS jackpot calls, emoji floods).
- Format variety:

  | Feature | Items |
  |---|---|
  | Emoji | 105 |
  | `₹` | 126 |
  | `Rs` | 5 |
  | lakh / लाख | 30 |
  | `50k`-style amounts | 9 |
  | Devanagari digits | 4 (c037, c107, c260, c301) |
  | ALL-CAPS-heavy | ~8 |
  | Letter-spaced text | 1 (c299) |
  | Multi-line emails or posts | several |

- Roman Hindi spelling varies: paisa/paise/pesa, guarantee/gaaranti, munafa/faida/fayda, roz/rozana, pakka/pakki, turant, abhi, jaldi.
- Mean text length is 229 characters for English, 176 for Hinglish and 159 for Hindi. The shortest item is 62 characters and the longest is 544.

## Exact counts

**Label × language**

| label | en | hi | hinglish | total |
|---|---|---|---|---|
| fraud | 45 | 38 | 45 | 128 (40.0%) |
| suspicious | 22 | 19 | 23 | 64 (20.0%) |
| benign | 45 | 39 | 44 | 128 (40.0%) |
| **total** | **112 (35.0%)** | **96 (30.0%)** | **112 (35.0%)** | **320** |

**Hard items (`hard: true`) by label × language**

| label (meaning of hard) | en | hi | hinglish | total |
|---|---|---|---|---|
| fraud (subtle) | 9 | 4 | 8 | 21 / 128 (16.4%) |
| suspicious (borderline) | 4 | 3 | 4 | 11 / 64 (17.2%) |
| benign (hard negative) | 34 | 26 | 35 | 95 / 128 (74.2%) |

- Subtle fraud ids: c027, c030, c059, c062, c075, c091, c093, c122, c126, c156, c176, c187, c190, c201, c219, c223, c251, c255, c282, c286, c314.
- Borderline suspicious ids: c063, c067, c072, c142, c150, c188, c195, c253, c264, c269, c308.

**Channel × label**

| channel | fraud | suspicious | benign | total |
|---|---|---|---|---|
| whatsapp | 36 | 26 | 37 | 99 |
| sms | 24 | 7 | 44 | 75 |
| social (comment, ad, post, news) | 14 | 19 | 25 | 58 |
| call | 26 | 3 | 7 | 36 |
| email | 12 | 4 | 12 | 28 |
| telegram | 16 | 5 | 3 | 24 |

**Channel × language**

| channel | en | hi | hinglish |
|---|---|---|---|
| whatsapp | 21 | 32 | 46 |
| sms | 22 | 29 | 24 |
| social | 26 | 15 | 17 |
| call | 10 | 11 | 15 |
| email | 24 | 3 | 1 |
| telegram | 9 | 6 | 9 |

**Signals (number of items flagged)**

| signal | fraud | suspicious |
|---|---|---|
| urgency | 55 | 4 |
| impersonation | 53 | 0 |
| unrealistic-return | 51 | 14 |
| personal-payment | 39 | 0 |
| suspicious-link | 32 | 1 |
| certainty | 30 | 5 |
| threat | 30 | 0 |
| unverified-app | 28 | 5 |
| credentials | 18 | 1 |
| withdrawal-fee | 15 | 0 |
| fake-ipo | 12 | 1 |
| remote-access | 12 | 0 |
| tips | 11 | 31 |
| chat-group | 9 | 16 |
| recovery-offer | 7 | 0 |
| borrowing | 4 | 20 |

On average a fraud item has 3.17 signals (subtle fraud: 1.48) and a suspicious item has 1.53.

## Coverage, with example ids

Fraud:

- **Fake trading apps and VIP groups:** c015, c100, c102, c161, c164 (long-con "pig butchering"), c196, c255, c260, c277, c296
- **Institutional, QIB, HNI or anchor quota, pre-IPO, guaranteed allotment:** c011, c065, c132, c225, c257, c286, c294, c296
- **Guaranteed or risk-free returns:** c006, c088, c112, c147, c182, c216, c272, c280, c309, c311
- **Periodic returns or money doubling:** c039, c048, c051, c070, c149, c153, c180, c209, c230, c275
- **Paid "100% accuracy" tips:** c002, c097, c129, c166, c198, c262
- **Operator or pump-and-dump tips:** c033, c123, c137, c317
- **Fee or tax before withdrawal:** c022, c041, c116, c158, c178, c190, c219, c265
- **Recovery agents:** c036, c075, c114, c201, c245, c289, c292
- **Impersonation of SEBI, RBI, NSE, BSE, police, CBI, ED, customs or TRAI, including digital arrest and money-laundering cases:** c003, c008, c017, c046, c068, c073, c084, c105, c141, c171, c193, c203, c206, c240, c267, c301, c304
- **Fake "SEBI registered" or "SEBI approved" claims:** c059, c060, c102, c112, c166, c182, c216, c280, c311
- **KYC or demat block threats with a link:** c008, c012, c107, c134, c174, c235, c238, c299
- **Requests for OTP, UPI PIN, password or CVV:** c017, c027, c030, c062, c086, c119, c156, c176, c187, c193, c211, c270, c282
- **Remote access or screen sharing:** c043, c055, c139, c233, c252, c277
- **Video-call custody:** c003, c046, c084, c171, c203, c301
- **APK links:** c054, c102, c144, c185, c252
- **Payment to a personal UPI ID or "this number":** c002, c022, c060, c082, c091, c097, c126, c166, c262, c317
- **Borrowing to invest:** c147, c214, c228, c272
- **Deepfake celebrity ads:** c024, c079, c109, c243
- **Crypto or forex bots:** c051, c070, c088, c185, c248, c309, c311
- **Ponzi and referral schemes:** c039, c088, c149, c153, c209, c275
- **Unauthorised deposit schemes:** c006, c077, c151, c180
- **Task scams that end in an "investment":** c019, c116, c158, c306
- **Other types:** dabba trading (c228), parcel phishing (c221), fake helpline in comments (c314), insurance-bonus fee (c223), fake exchange claim payout (c169)

Suspicious:

- **Unsolicited tips:** c005, c040, c076, c154, c200, c232, c236
- **Free channel or group invites:** c020, c028, c049, c080, c120, c145, c179, c227, c291, c303
- **Borrowing to trade:** c009, c025, c035, c090, c094, c115, c125, c159, c168, c172, c217, c246, c249, c274, c279, c298
- **Stranger or "mentor" openers:** c085, c099, c259
- **Courses with income hooks:** c044, c188, c204
- **Unknown apps, algos or leverage:** c057, c110, c163, c253, c315
- **Hype and influencer picks:** c067, c072, c150, c207, c212, c264, c284
- **Second-hand fixed-return schemes:** c131, c222, c241
- **Grey-market IPO forms:** c269

Hard negatives (benign):

- **OTP and transaction SMS that say "do not share":** c001, c037, c042, c078, c111, c162, c202, c231, c237, c261
- **Margin or debit-balance notices:** c010, c074, c194
- **Contract notes and statements:** c034, c101, c205
- **IPO reminders, mandates and allotment notices:** c018, c098, c130, c135, c320
- **KYC or nomination reminders that point only to the official app or branch:** c050, c118, c167, c273
- **Mutual fund messages:** c004, c071, c133, c165, c247
- **Official awareness messages:** c013, c016, c066, c069, c089, c140, c157, c181, c220, c250, c266, c283
- **News about fraud arrests:** c045, c113, c138, c218, c224
- **Family or friends discussing FDs, SIPs, gold, loans or chit funds:** c026, c029, c053, c096, c103, c108, c124, c143, c186, c192, c210, c213, c244, c281
- **Forwarded scam warnings:** c007, c081, c146, c173, c175, c215, c239, c242, c271, c276, c307
- **Genuine loan or credit offers:** c032, c064, c234
- **Bill reminders:** c031, c058, c106, c197, c256
- **Genuine bank or broker calls:** c127, c191, c254, c258
- **Others:** LPG delivery code (c152), card blocked after wrong PIN (c155), broker anti-fraud advisory (c170), F&O risk disclosure (c226)

## Suggested scoring

- Use the set once, for the final measurement. Report the 3-class confusion matrix.
- Also report a binary view, with fraud + suspicious counted as "flag" and benign as "no flag".
- Report fraud recall, subtle-fraud recall (21 items), the false-positive rate on all benign items, and the false-positive rate on the 95 hard negatives.
- Each result should be shown per language as well.
- Calling a suspicious item "fraud" is a milder error than missing a fraud.
- The 40/20/40 mix is **not** real-world prevalence, so precision on live traffic will differ.

## Known weaknesses and limitations

- **Synthetic, and written by a language model.** Messages are cleaner and more "textbook" than real scams:
  - few typos;
  - Hindi is mostly standard Devanagari;
  - no regional languages;
  - no speech-recognition noise in the call transcripts;
  - single messages only, with no threads, images, QR codes or voice notes.
- **One annotator, who was also the author.** There is no inter-annotator agreement, so labels and signals reflect one person's judgement. A second annotator pass over the borderline ids below is recommended.
- **Borderline labels.** Different reviewers could label these items differently:
  - Fraud that could be read as suspicious:
    - c033, c123, c137: operator calls with no direct payment ask
    - c048: testimonial comment
    - c075, c201: recovery testimonials
    - c077: 24% credit society
    - c228: dabba trading, which is illegal rather than plainly deceptive
    - c230: doubling offer with only a contact number
    - c255: follow-up nudge
    - c314: fake helpline, where the only clue is a mobile number labelled toll-free
  - Suspicious that could be read as fraud:
    - c131, c222, c241: second-hand fixed-return schemes
    - c163: offshore forex
    - c253: API-key request
    - c315: sideloaded app
    - c104: phone-number harvesting
  - Suspicious that could be read as benign: c063, c067, c072, c150, c195, c264, c308.
  - Benign that a cautious reader might flag: c127 (bank monitoring call), c162 (transfer OTP), c152 (delivery code), c103 (grey-market chatter), c192 (jeweller scheme), c213 (chit fund).
- **Signal judgement calls:**
  - `t.me` and WhatsApp invite links are counted as `chat-group`, not `suspicious-link`.
  - "Stay on video call" and "allow all permissions" count as `remote-access`.
  - Fake registration claims and celebrity endorsements count as `impersonation`.
  - Release and recovery fees count as `withdrawal-fee`.
  - Cash collection and payment to a "company" or "escrow" account count as `personal-payment`.
  - Institutional block deals and grey-market forms count as `fake-ipo` (a stretch for c269).
- **Thin cells:**
  - Email is mostly English (24 of 28).
  - Telegram has only 3 benign items.
  - Devanagari digits appear in only 4 items, and letter-spaced text in only 1.
  - Hinglish spelling variation is present but limited.
- **Made-up names, numbers and domains may coincide with real ones by chance.**
- **Dates and rates are pinned to around Sep–Oct 2026.**
