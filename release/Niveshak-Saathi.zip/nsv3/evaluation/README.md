# Evaluation pack: how accurate is the message checker?

This folder lets anyone reproduce the blind results in `../Blind-Evaluation.json`.

## The sets

Three sealed sets of 320 synthetic messages each: 128 fraud, 64 suspicious and 128 ordinary. Each was written by a separate AI agent that never saw the checker, and never saw the earlier sets.

| File | Ordinary messages that are tricky look-alikes | How it was used |
|---|---|---|
| `blind-v3.json` | 78 of 128 | Scored once to measure v2.0 and v3.0, then used as development data for v3.1 and v3.2 |
| `blind-v4.json` | 95 of 128 | Scored once after v3.1 was frozen, then used as development data for v3.2 |
| `blind-v5.json` | 90 of 128 | Never used for development. Scored **once**, after v3.2 was frozen. **This is the headline result.** |
| `../prototype/evaluation-cases.json` | — | Developer-written regression cases used during development; `../Rule-Evaluation.json` is optimistic by construction |

Each set has its own README (`README-blind-v3.md` and so on) with counts, borderline items and limitations.

## Reproduce

Run these from the extracted submission folder:

```text
node evaluation/score-blind.cjs prototype/engine.js evaluation/blind-v5.json
node evaluation/score-blind.cjs evaluation/engines/v3.1-engine.js evaluation/blind-v5.json
node evaluation/score-blind.cjs evaluation/engines/v2.0-engine.js evaluation/blind-v5.json
```

The script prints rates with 95% Wilson intervals and never prints message text.

**How a verdict is counted:**
- **Warned:** the checker gave Caution or High.
- **High:** the stop verdict.
- **v2.0:** it has no risk level, so the app's v2 rule is used (two or more signs give High, one gives Caution).

## Limits

- **Synthetic:** the messages were written by AI agents, not collected from real victims, and each set has one annotator.
- **Not real-world prevalence:** the 40/20/40 mix is a test design, so report per-class rates.
- **Not proof of protection:** these numbers measure the checker on these messages. They do not show money saved or fraud avoided.
