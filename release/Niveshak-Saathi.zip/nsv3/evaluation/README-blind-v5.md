# blind-v5: held-out evaluation set for the Niveshak Saathi message checker

`blind-v5.json` holds 320 short synthetic messages of the kind Indians receive by SMS, WhatsApp, Telegram, social media comments and ads, email, and phone calls (written as the caller's words). Each message is labelled `fraud`, `suspicious` or `benign`.

**Use it only for the final accuracy measurement.** Do not tune rules, thresholds or prompts on it. Once results have been looked at, the set is no longer blind.

## How it was made
- Written fresh on 2026-10-02 by an independent Claude agent. The agent did not see the checker (engine, rules, app), earlier test sets, earlier READMEs or `outputs/`, and it ran no checker.
- Vocabulary, names, amounts, formats, tone and length were varied on purpose. Some messages include emoji, ALL CAPS, odd spacing, Devanagari digits (71 items), "Rs", "₹", "lakh" and "k".
- All people, companies, apps, banks, brokers, phone numbers, UPI IDs and domains are invented. The only real names used are regulators, exchanges and agencies (SEBI, RBI, NSE, BSE, IRDAI, CBI, ED, customs, police, IEPF), the 1930 cyber-fraud helpline, and platform names (WhatsApp, Telegram).
- Text length ranges from 46 to 323 characters (mean 149).

## Schema
Top-level fields are `version`, `createdAt`, `author`, `taxonomy` (16 signal ids, each with a one-line definition) and `items`. Each item has these fields:

| field | meaning |
|---|---|
| `id` | `d001` to `d320` |
| `lang` | `en`, `hi` (Devanagari) or `hinglish` (Roman Hindi with spelling variation) |
| `channel` | `sms`, `whatsapp`, `telegram`, `social`, `email` or `call` |
| `label` | `fraud`, `suspicious` or `benign` |
| `hard` | see the next section |
| `signals` | the signal ids a careful human would flag; always empty for benign items |
| `text` | the message |
| `note` | a short reason for the label |

Label definitions:
- **fraud**: a clear attempt to get money, credentials or device access by deception.
- **suspicious**: risky but not clearly a scam on its own. Examples are unsolicited tips with no payment ask, invites to free tips channels, pushes to borrow in order to trade, and vague high-return offers with no payment ask.
- **benign**: an ordinary, legitimate message.

What `hard` means depends on the label:
- **benign, hard = true**: a hard negative. The message contains risky-looking words in a safe context, such as an OTP or debit SMS with a "do not share" line, a margin notice, a contract note, a UPI-mandate IPO reminder, a KYC reminder that points only to the official app or branch, an awareness message, fraud news, a family chat about FDs, SIPs, gold or loans, or a forwarded scam warning.
- **fraud, hard = true**: a subtle fraud with only one or two weak signs, often polite and professional.
- **suspicious, hard = true**: a borderline case that sits close to benign or to fraud.

## Exact counts

### Label by language
| label | en | hi | hinglish | total |
|---|---|---|---|---|
| fraud | 45 | 38 | 45 | **128** |
| suspicious | 22 | 19 | 23 | **64** |
| benign | 45 | 39 | 44 | **128** |
| **total** | **112** | **96** | **112** | **320** |

### Hard items (hard / all)
| label | en | hi | hinglish | total |
|---|---|---|---|---|
| fraud (subtle) | 7/45 | 5/38 | 7/45 | **19/128** (14.8%) |
| suspicious (borderline) | 4/22 | 4/19 | 4/23 | **12/64** |
| benign (hard negative) | 32/45 | 27/39 | 31/44 | **90/128** (70.3%) |
| **total hard** | 43 | 36 | 42 | **121** |

### Channels
| channel | fraud | suspicious | benign | total | en | hi | hinglish |
|---|---|---|---|---|---|---|---|
| whatsapp | 40 | 21 | 45 | 106 | 33 | 30 | 43 |
| sms | 24 | 3 | 50 | 77 | 29 | 24 | 24 |
| email | 14 | 6 | 24 | 44 | 19 | 13 | 12 |
| social | 14 | 19 | 9 | 42 | 15 | 13 | 14 |
| telegram | 11 | 15 | 0 | 26 | 8 | 8 | 10 |
| call | 25 | 0 | 0 | 25 | 8 | 8 | 9 |

### How often each signal is used (number of items)
| signal | fraud | suspicious |
|---|---|---|
| impersonation | 54 | 0 |
| urgency | 53 | 13 |
| unrealistic-return | 49 | 35 |
| personal-payment | 46 | 0 |
| suspicious-link | 42 | 0 |
| threat | 33 | 0 |
| certainty | 31 | 3 |
| unverified-app | 25 | 1 |
| credentials | 16 | 0 |
| withdrawal-fee | 15 | 0 |
| remote-access | 10 | 0 |
| tips | 9 | 32 |
| fake-ipo | 9 | 1 |
| chat-group | 7 | 16 |
| recovery-offer | 5 | 0 |
| borrowing | 3 | 16 |

## Fraud and suspicious types covered
The set covers these types across all three languages and several channels:
- fake trading apps and WhatsApp or Telegram "VIP" groups
- institutional account, QIB, anchor or HNI quota, pre-IPO offers, and guaranteed IPO allotment
- guaranteed returns, daily, weekly or monthly returns, and money doubling
- paid "100% accuracy" tips, and operator or pump-and-dump calls
- taxes, upgrade fees or "security deposits" demanded before a withdrawal
- recovery agents and fake "SEBI refund cells" that charge a fee
- impersonation of SEBI, RBI, NSE, BSE and IRDAI
- CBI, ED, police and customs digital-arrest calls, including "stay on video call"
- fake "SEBI registered" or "SEBI approved" claims
- KYC, demat or PAN "will be blocked" messages with a link
- requests for an OTP, UPI PIN, password, TOTP or CVV
- screen-sharing or remote-support apps, and APK links
- lookalike domains
- payment to a personal UPI ID, a phone number or a personal QR code
- pushes to borrow in order to invest
- deepfake-style celebrity ads, where the celebrity is invented
- crypto and forex bots, and mining apps
- Ponzi or referral clubs, and unauthorised deposit or "society" schemes
- task scams that turn into an "investment"
- romance or wrong-number "friendly stranger" chats

A few fraud items are general scams with no investment angle (electricity disconnection, failed parcel delivery, marketplace UPI-PIN request, card CVV), because the checker will see these too.

## Borderline items
- **Subtle fraud** (`fraud`, hard): d037, d038, d061, d070, d080, d094, d098, d135, d137, d167, d169, d199, d235, d237, d270, d272, d274, d309, d311. Each of these has only one or two weak signs, such as one lookalike link, a single polite OTP request, an off-platform payment, or a small "processing fee". d167 and d098 are early-stage wrong-number or romance approaches that are labelled fraud because they steer toward a platform.
- **Borderline suspicious** (`suspicious`, hard): d021, d041, d065, d083, d126, d150, d162, d190, d222, d251, d263, d300. These include relatives or friends passing on tips or high-return desks, influencer tips with a disclaimer, a loan ad that mentions stock investing, and a distributor's pushy post based on past returns.
- **Other judgement calls:**
  - d032: an unlisted pre-IPO share offer with no payment details. Labelled suspicious; a stricter reader could call it fraud.
  - d046: a testimonial comment that tells readers to "deposit with her". Labelled fraud.
  - d059 and d085: vague high returns with no ask. Labelled suspicious.
  - d071, d093, d267: leverage or margin-funding ads that a genuine broker could send. Labelled suspicious.
  - d204 and d279: scheduled supply-cut notices. Labelled benign; d204 is marked hard.
  - d276: an OTP-at-delivery SMS. Labelled benign and hard.
  - d109, d203, d318: genuine bank offers with no pressure. Labelled benign and hard.

## Limitations
- **The data is synthetic.** The messages imitate real formats but were not collected from real users. Real scam traffic is longer, messier and changes quickly, and it often comes with images, voice notes or forwarded screenshots. None of that is included here.
- **There was one annotator.** The same agent wrote and labelled every item, and no second annotator checked the labels, so agreement between annotators cannot be measured. The `signals` lists record one person's judgement. Expect the most disagreement on the suspicious-versus-fraud and suspicious-versus-benign boundaries listed above.
- **The class mix is set by design.** The 40/20/40 split and the 70% share of hard negatives do not reflect real-world prevalence, so precision on real traffic will differ.
- **Language coverage is limited.** Only English, Hindi and Hinglish are included; there are no other Indian languages and no code-mixing beyond Hindi. Hinglish spelling varies, but one writer cannot cover all regional variants.
- **Invented names may still match something real.** Names, numbers, UPI handles and domains were made up, but some may happen to match real entities by coincidence. Do not visit any of the domains.
- **Telegram and call messages are fewer than WhatsApp and SMS.** Calls appear only as fraud.
