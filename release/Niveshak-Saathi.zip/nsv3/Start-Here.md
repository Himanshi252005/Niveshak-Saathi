# Niveshak Saathi: Release 3.2 submission pack

1. **Open the app.** Open `prototype/dist/index.html` in a browser.
   - It starts in Hindi; use the language selector for English.
   - It runs locally without installation and works offline.
   - It opens on **Home**, which asks one question, "What do you need help with?", and offers six large choices in everyday words.
   - The sidebar menu groups every tool under three plain headings. On a phone, the labelled **Menu** button opens it. "Get urgent help" stays in the top bar on every page.
2. **Read the submission.** `Submission-v3.md` covers:
   - how each of the five judging criteria is met, with evidence and limits;
   - the model and its blind evaluation on three sealed sets;
   - the three-minute pitch, the demo script, and answers to likely judge questions.
3. **Check the evidence.** Read `Validation-v3.md`. The JSON records are:
   - `Release-3.2-Verification.json`: every suite, run on the release build;
   - `Browser-Validation.json`: the browser suite over several runs, with load times;
   - `Blind-Evaluation.json`: every model version on three sealed blind sets;
   - `Rule-Evaluation.json`: developer regression cases.
4. **Reproduce the checker results** from this folder:
   - developer cases: `node Evaluate-Rules.cjs`;
   - sealed blind set: `node evaluation/score-blind.cjs prototype/engine.js evaluation/blind-v5.json` (see `evaluation/README.md`).
5. **Run a pilot.** Open the app's **More tools → Pilot session (facilitators)**. With `Operations-and-Pilot-Kit.md` it runs a consented pilot with fictional scenarios and downloads anonymous rows in the `Pilot-Results.csv` columns. No user-study outcomes have been invented; the pilot has not yet been run.
6. **Publish.** Follow `Publish-Checklist.md`: the verified file, compression, and a public link for judges.
7. **Edit and rebuild.** Owners edit reviewed content in the local Owner Studio (`prototype/owner-studio.html`; see `prototype/OWNER-GUIDE.md`). After changing content or code, rebuild with `node prototype/build.cjs`.

**What the app does and does not do:**
- **Downloads and sharing:** complaint, action-card, safety-step, family-card and habit text files; a clean offline HTML copy; anonymous practice and pilot results; and "Share this app".
- **It does not:** file complaints, connect accounts, give stock tips, certify that an offer is safe, or recover money.

**Device notes:**
- Official reporting websites need connectivity.
- Installed local speech voices vary by device; the app explains how to add a Hindi voice.
- Voice input uses the phone keyboard's own microphone.
- Results and drafts last only for the session; downloaded files stay until deleted separately.

**Demos:** use fictional information. Never call an official helpline or file a complaint merely to demonstrate the prototype.

**Status:** Release 3.2 has been prepared and verified locally but not published; see `Delivery-Status.md`. Version 2 stays the hosted version until the owner redeploys.
